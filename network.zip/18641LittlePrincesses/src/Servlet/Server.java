package Servlet;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entities.Seller;
import Entities.SellerRest;

/**
 * Servlet implementation class Server
 */
@WebServlet("/Server/*")
public class Server extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Server() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String url = request.getRequestURI().toString();
        int index = url.indexOf("Server/");
        String getType = url.substring(index + 7);
        DataOutputStream out = new DataOutputStream(response.getOutputStream());
        
        //get restuarants from database
        if(getType.equals("getRestuarants")) {

        	out.writeUTF("hahah");
        	out.flush();
        	out.close();
        }
        //get menus from database
        else {
        	out.writeUTF("menus");
        	out.flush();
        	out.close();
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	//update the existing menu
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		DataInputStream in = new DataInputStream(request.getInputStream());
        DataOutputStream out = new DataOutputStream(response.getOutputStream());
        
        String email = in.readUTF();
        String dishName = in.readUTF();
        double price = in.readDouble();
        in.close();
        
        //update to database
        out.writeUTF(email);
        
	}
	
	
	//create new restuarant or menu
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String url = request.getRequestURI().toString();
        int index = url.indexOf("Server/");
        String getType = url.substring(index + 7);
		
		DataInputStream in = new DataInputStream(request.getInputStream());
        DataOutputStream out = new DataOutputStream(response.getOutputStream());
        
        //create new restuarant in database
        if(getType.equals("restuarant")) {
        	
        	String email = in.readUTF();
            String resName = in.readUTF();
            String Description = in.readUTF();
            String location = in.readUTF();
            in.close();
            out.writeUTF(resName);
            out.flush();
            out.close();
        }
        //create new menu in restuarant
        else {
        	
        	String email = in.readUTF();
            String dishName = in.readUTF();
            double price = in.readDouble();
            in.close();
            out.writeUTF(dishName);
            out.flush();
            out.close();
        }    
	}
	
	//delete the menu according to the user email account
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String url = request.getRequestURI().toString();
        int index = url.indexOf("Server/");
        String menuName = url.substring(index + 7);
        
        index = url.indexOf("+");
        String email = url.substring(index+1);
        
        //insert into database
        
	}

}
