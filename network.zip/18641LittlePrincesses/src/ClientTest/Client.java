package ClientTest;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import Entities.*;

public class Client {

	public static void main(String[] args) throws ProtocolException, IOException {
        
		SellerMenu menu = new Seller();
	    menu.setDishName("dish");
	    menu.setEmail("dfd@gmail.com");
	    menu.setPrice(12.99);
	    
	    SellerRest res = new Seller();
	    res.setDescription("ha");
	    res.setEmail("dfd");
	    res.setLocation("china");
	    res.setResName("greatRes");
	    
        post(menu);
        get("getRestuarants");
        putMenu(menu);
        putRestuarant(res);
        deleteMenu("dish", "99@dk.com");
    }
    
	public static void get(String getType) throws IOException {
		
		URL url = new URL("http://localhost:8080/18641LittlePrincesses/Server/" + getType);
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        //set the method as post
        conn.setRequestMethod("GET");
        conn.setDoInput(true);
        conn.connect();
        
        DataInputStream in = new DataInputStream(conn.getInputStream());
        System.out.println(in.readUTF());
        in.close();
        
	}


    public static void post(SellerMenu newMenu) throws MalformedURLException, ProtocolException, IOException {
        
        URL url = new URL("http://localhost:8080/18641LittlePrincesses/Server");
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        //set the method as post
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        
       //use the outputStream to send the menu information
        DataOutputStream out = new DataOutputStream(conn.getOutputStream());
        out.writeUTF(newMenu.getEmail());
        out.writeUTF(newMenu.getDishName());
        out.writeDouble(newMenu.getPrice());
        out.flush();
        out.close();
        conn.connect();
         
        DataInputStream in = new DataInputStream(conn.getInputStream());
        System.out.println((String)in.readUTF());
    }
    
    public static void putMenu(SellerMenu newMenu) throws MalformedURLException, ProtocolException, IOException {
        
        URL url = new URL("http://localhost:8080/18641LittlePrincesses/Server/menu");
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        //set the method as post
        conn.setRequestMethod("PUT");
        conn.setDoOutput(true);
        
       //use the outputStream to send the menu information
        DataOutputStream out = new DataOutputStream(conn.getOutputStream());
        out.writeUTF(newMenu.getEmail());
        out.writeUTF(newMenu.getDishName());
        out.writeDouble(newMenu.getPrice());
        out.flush();
        out.close();
        conn.connect();
         
        DataInputStream in = new DataInputStream(conn.getInputStream());
        System.out.println((String)in.readUTF());
    }
    
public static void putRestuarant(SellerRest newRes) throws MalformedURLException, ProtocolException, IOException {
        
        URL url = new URL("http://localhost:8080/18641LittlePrincesses/Server/restuarant");
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        //set the method as post
        conn.setRequestMethod("PUT");
        conn.setDoOutput(true);
        
       //use the outputStream to send the spy information
        DataOutputStream out = new DataOutputStream(conn.getOutputStream());
        out.writeUTF(newRes.getEmail());
        out.writeUTF(newRes.getResName());
        out.writeUTF(newRes.getDescription());
        out.writeUTF(newRes.getLocation());
        out.flush();
        out.close();
        conn.connect();
         
        DataInputStream in = new DataInputStream(conn.getInputStream());
        System.out.println((String)in.readUTF());
    }

public static void deleteMenu(String name, String email) throws IOException {
	
	URL url = new URL("http://localhost:8080/18641LittlePrincesses/Server/" + name + "+" + email);
    HttpURLConnection conn = (HttpURLConnection)url.openConnection();
    //set the method as post
    conn.setRequestMethod("DELETE");
    conn.connect();
    
    System.out.println(conn.getResponseCode());
}

}
