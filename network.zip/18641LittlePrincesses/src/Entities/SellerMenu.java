package Entities;

public interface SellerMenu {

    public String getEmail();
    public String getDishName();
    public double getPrice();

    public void setEmail(String mail);
    public void setDishName(String name);
    public void setPrice(double p);

}
