package Entities;

public interface SellerLogin {

    public String getEmail();
    public String getPW();

    public void setEmail(String mail);
    public void setPW(String pw);
}
