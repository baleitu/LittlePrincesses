import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class MySQLDataBase {
	
	// database name
    private static final String DATABASE_NAME = "test";
    private static final String TABLE_ACCOUNT = "UserAccount";
    private static final String TABLE_SELLER = "Seller";
    private static final String TABLE_MENU = "Menu";
    private static final String[] ACCOUNT_COLUMN = {"email","password"};
    
	public static Connection buildConnection() throws SQLException, IOException {

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		String url = "jdbc:mysql://localhost:3306/" + DATABASE_NAME;
		String username = "root";
		String password = "";

		return DriverManager.getConnection(url, username, password);
	}

	public static void createTable(Statement statement) throws SQLException, IOException {
		String createQuery = "create table " + TABLE_ACCOUNT +
                //" (_id integer auto_increment, email char(40), password char(40), PRIMARY KEY (_id));";
				" (email char(40), password char(40), PRIMARY KEY (email));";
		statement.executeUpdate(createQuery); // execute the query

        createQuery = "create table " + TABLE_SELLER +
                //" (_id integer auto_increment, restName char(40), restPic BLOB, location char(40), description char(40),"
        		" (_id integer auto_increment, restName char(40), location char(40), description char(40),"
                + "sellerEmail char(40), PRIMARY KEY (_id), FOREIGN KEY (sellerEmail) REFERENCES "+ TABLE_ACCOUNT 
                + "(email) ON UPDATE CASCADE ON DELETE CASCADE);";
        statement.executeUpdate(createQuery);

        createQuery = "create table " + TABLE_MENU +
                //"(_id integer auto_increment, dishName char(40), restPic BLOB, price double,"
        		"(_id integer auto_increment, dishName char(40), price double,"
                +"resID integer, PRIMARY KEY (_id), FOREIGN KEY (resID) REFERENCES "+ TABLE_SELLER 
                + "(_id) ON UPDATE CASCADE ON DELETE CASCADE);";
        statement.executeUpdate(createQuery);
	}

    public static void insertBuyer(Statement statement, BuyerLogin buyer) throws SQLException {
    	
    	String query = "select * from " + TABLE_ACCOUNT + " where email = '" + buyer.getEmail() + "';";
		ResultSet rs = statement.executeQuery(query);
		
		if (rs.next() == true) {
			System.out.println("Error: The buyer account already exists!");
			return;
		}
		
    	String command = "insert into " + TABLE_ACCOUNT + " values ('" + buyer.getEmail() + "', '" + buyer.getPW() + "')";
		statement.executeUpdate(command);
    }

    public static void insertSeller(Statement statement, SellerLogin seller) throws SQLException {
    	
    	String query = "select * from " + TABLE_ACCOUNT + " where email = '" + seller.getEmail() + "';";
		ResultSet rs = statement.executeQuery(query);
		
		if (rs.next() == true) {
			System.out.println("Error: The seller account already exists!");
			return;
		}
		
    	String command = "insert into " + TABLE_ACCOUNT + " values ('" + seller.getEmail() + "', '" + seller.getPW() + "')";
		statement.executeUpdate(command);
    }
    
    public static Boolean loginCheckBuyer(Statement statement, BuyerLogin buyer) throws SQLException {
    	
    	String query = "select * from " + TABLE_ACCOUNT + " where email = '" + buyer.getEmail() + "';";
		ResultSet rs = statement.executeQuery(query);
		
		if (rs.next() == false) {
			System.out.println("Error: The buyer account doesn't exists!");
			return false;
		}
		
		String pwd = rs.getString("password");
		if(!pwd.equals(buyer.getPW())){
			System.out.println("Error: The password of buyer account isn't right!");
			return false;
		}
		
		return true;
    }
    
    public static Boolean loginCheckSeller(Statement statement, SellerLogin seller) throws SQLException {
    	
    	String query = "select * from " + TABLE_ACCOUNT + " where email = '" + seller.getEmail() + "';";
		ResultSet rs = statement.executeQuery(query);
		
		if (rs.next() == false) {
			System.out.println("Error: The seller account doesn't exists!");
			return false;
		}
		
		String pwd = rs.getString("password");
		if(!pwd.equals(seller.getPW())){
			System.out.println("Error: The password of seller account isn't right!");
			return false;
		}
		
		return true;
    }

    public static void insertRestaurant(Statement statement, SellerRest res) throws SQLException {

    	String command = "insert into " + TABLE_SELLER + " values (null, '" + res.getResName() + "', '" + res.getLocation() 
    			+ "', '" + res.getDescription() + "', '" + res.getEmail() + "')";
		statement.executeUpdate(command);
    }

    public static void insertMenu(Statement statement, SellerMenu menu) throws SQLException {
    	
    	String query = "select _id from " + TABLE_SELLER + " where sellerEmail = '" + menu.getEmail() + "';";
		ResultSet rs = statement.executeQuery(query);
		int resID = 0;
		
		while (rs.next()) {
			resID = rs.getInt("_id");			
		}
    	
		String command = "insert into " + TABLE_MENU + " values (null, '" + menu.getDishName() + "', " + menu.getPrice() 
				+ ", " + resID + ")";
		statement.executeUpdate(command);
    }

    public static void updateMenu(Statement statement, SellerMenu menu, String oriDishName) throws SQLException {

    	String query = "select _id from " + TABLE_SELLER + " where sellerEmail = '" + menu.getEmail() + "';";
		ResultSet rs = statement.executeQuery(query);
		int resID = 0;
		
		while (rs.next()) {
			resID = rs.getInt("_id");			
		}
		
    	String command = "update " + TABLE_MENU + " set " + TABLE_MENU + ".dishName = '" + menu.getDishName() 
    			+ "', " + TABLE_MENU + ".price = " + menu.getPrice() + " where " 
    			+ TABLE_MENU + ".resID = " + resID + " and " + TABLE_MENU + ".dishName = '" + oriDishName + "';";
		statement.executeUpdate(command);
    }

    public static void deleteMenu(Statement statement, SellerMenu menu) throws SQLException {

    	String query = "select _id from " + TABLE_SELLER + " where sellerEmail = '" + menu.getEmail() + "';";
		ResultSet rs = statement.executeQuery(query);
		int resID = 0;
		
		while (rs.next()) {
			resID = rs.getInt("_id");			
		}
		
		String command = "delete from " + TABLE_MENU + " where " + "resID = "+ resID + " and dishName = '" + menu.getDishName() + "';";
		statement.executeUpdate(command);
    }

    public static ArrayList<SellerRest> getRestaurants(Statement statement) throws SQLException{

        ArrayList<SellerRest> restaurants = new ArrayList<>();
        String query = "select * from " + TABLE_SELLER;
		ResultSet rs = statement.executeQuery(query);
		int resID = 0;
		
		while (rs.next()) {
			Seller res = new Seller();
			res.setResName(rs.getString("restName"));
            res.setLocation(rs.getString("location"));
            res.setDescription(rs.getString("description"));
            res.setEmail(rs.getString("sellerEmail"));
            restaurants.add(res);			
		}

        return restaurants;
    }

    public static ArrayList<SellerMenu> getMenus(Statement statement, SellerRest restaurant) throws SQLException {

        ArrayList<SellerMenu> menus = new ArrayList<>();

        String query = "select _id from " + TABLE_SELLER + " where sellerEmail = '" + restaurant.getEmail() + "';";
		ResultSet rs = statement.executeQuery(query);
		int resID = 0;
		
		while (rs.next()) {
			resID = rs.getInt("_id");			
		}
		
		String command = "select * from " + TABLE_MENU + " where resID = " + resID;
		rs = statement.executeQuery(command);
		
		while (rs.next()) {
			Seller res = new Seller();
			res.setDishName(rs.getString("dishName"));
            res.setPrice(rs.getDouble("price"));
            menus.add(res);			
		}
		
        return  menus;
    }
    
	public static void main(String arg[]) throws SQLException, IOException {

		Connection connection = buildConnection();
		Statement statement = connection.createStatement();

		BuyerLogin buyerLogin = new Buyer ("buyer@gmail.com", "123");
		SellerLogin sellerLogin = new Seller ();
		sellerLogin.setEmail("seller@gmail.com");
		sellerLogin.setPW("123");
		
		//System.out.println("Now we have created new tables!");
		//createTable(statement);
		
		//System.out.println("\nAdd new Buyer to database:");		
		//MySQLDataBase.insertBuyer(statement, buyerLogin);		
		
		//System.out.println("\nAdd new Seller to database:");		
		//MySQLDataBase.insertSeller(statement, sellerLogin);
		
		//System.out.println("\nBuyer Login Check:");		
		//MySQLDataBase.loginCheckBuyer(statement, buyerLogin);
		
		System.out.println("\nSeller Login Check:");		
		MySQLDataBase.loginCheckSeller(statement, sellerLogin);
		
		///////////////////////////////////////////////////////////////////////////
		
		/*System.out.println("\nAdd new SellerRest to database");	
		SellerRest sellerRest = new Seller();
		sellerRest.setEmail("seller@gmail.com");
		sellerRest.setLocation("Forbes St");
		sellerRest.setResName("Little Asia");
		sellerRest.setDescription("Grest rest");
		
		MySQLDataBase.insertRestaurant(statement, sellerRest);*/
		
		/*System.out.println("\nAdd new SellerMenu to database");	
		SellerMenu sellerMenu = new Seller();
		sellerMenu.setEmail("seller@gmail.com");
		sellerMenu.setDishName("Fish Noodel");
		sellerMenu.setPrice(10);
		MySQLDataBase.insertMenu(statement, sellerMenu);*/
		
		/*System.out.println("\nUpdate SellerMenu to database");	
		SellerMenu sellerMenu = new Seller();
		sellerMenu.setEmail("seller@gmail.com");
		sellerMenu.setDishName("New Fish Noodel");
		sellerMenu.setPrice(100);
		MySQLDataBase.updateMenu(statement, sellerMenu, "Fish Noodel");*/
		
		/*System.out.println("\nDelete SellerMenu from database");	
		SellerMenu sellerMenu = new Seller();
		sellerMenu.setEmail("seller@gmail.com");
		sellerMenu.setDishName("New Fish Noodel");
		sellerMenu.setPrice(100);
		MySQLDataBase.deleteMenu(statement, sellerMenu);*/
		
		/*System.out.println("\nGet rest from database");	
		ArrayList<SellerRest> sellerrest = MySQLDataBase.getRestaurants(statement);
		for(SellerRest rest : sellerrest){
			System.out.println("Rest Name is : " + rest.getResName());
		}*/
		
		/*System.out.println("\nGet menu from database");	
		SellerRest sellerRest = new Seller();
		sellerRest.setEmail("seller@gmail.com");
		sellerRest.setLocation("Forbes St");
		sellerRest.setResName("Little Asia");
		sellerRest.setDescription("Grest rest");
		ArrayList<SellerMenu> sellerMenu = MySQLDataBase.getMenus(statement, sellerRest);
		for(SellerMenu menu : sellerMenu){
			System.out.println("Dish Name is : " + menu.getDishName());
		}*/
	}
}
